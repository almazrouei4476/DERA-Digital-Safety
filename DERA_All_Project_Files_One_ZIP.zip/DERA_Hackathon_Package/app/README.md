# DERA | دِرع — Hackathon MVP

## Overview
DERA is an early-stage digital-safety prototype. It checks user-entered message text and URL strings for selected warning signs and explains the indicators with practical safety guidance.

## Implemented in this version
- Arabic RTL interface with a basic English toggle.
- Message and URL analysis using local heuristic rules.
- Explainable warning indicators and suggested next steps.
- Responsive mobile-first layout.
- PWA manifest and service worker for installability/offline shell.

## Important limitations
This build does **not** call an external AI model, threat-intelligence database, bank, telecom provider, or government system. The analyzer is a deterministic rules-based prototype, not a validated cybersecurity product. A low-indicator result is not proof of safety. Do not submit real passwords, OTPs, banking data, or private conversations.

## Run locally
1. Extract the package.
2. Open the `app` folder in Visual Studio Code.
3. Install the Live Server extension and open `index.html` with Live Server.
4. Or run `python -m http.server 8000` from the `app` folder and open `http://localhost:8000`.

## Install on a phone
Host the `app` folder on an HTTPS static host. Open it in Safari/Chrome and use the browser's Add to Home Screen / Install App option. PWA installation behavior varies by browser.

## Repository structure
- `app/index.html` — interface
- `app/style.css` — visual design
- `app/app.js` — local analysis logic
- `app/manifest.json` — PWA metadata
- `app/sw.js` — service worker
- `app/icon.svg` — app icon
- `documentation/` — technical and judging notes
- `presentation/` — editable presentation

## Suggested next steps
1. Add a backend API with input validation and rate limiting.
2. Integrate a reputable URL reputation service after reviewing licensing, privacy, and data-transfer implications.
3. Add an AI analysis service only with explicit consent, redaction, secure secret handling, and human-reviewed evaluation.
4. Build a labeled test set and report precision, recall, false-positive rate, and latency; do not claim accuracy before testing.
5. Conduct security, privacy, accessibility, and legal reviews before any public deployment.

## Team of three
- Member 1: product/UI, user testing, Arabic/English content.
- Member 2: analysis rules, test cases, code review.
- Member 3: GitHub, README, presentation, demo coordination.

## Demo test cases
- Message asking for OTP and password under time pressure.
- Benign informational message.
- URL using HTTP.
- URL with suspicious-looking terms (demonstrates why a flag is not proof).
Record actual outputs during rehearsal.
