const $=id=>document.getElementById(id);
let mode="message", english=false;
const examples={message:"تنبيه عاجل: سيتم إيقاف حسابك البنكي خلال 10 دقائق. اضغط على الرابط وأدخل كلمة المرور ورمز التحقق لتحديث بياناتك.",url:"http://secure-bank-account-update.example-login.com/verify"};
$("year").textContent=new Date().getFullYear();
$("content").addEventListener("input",()=> $("count").textContent=$("content").value.length+(english?" chars":" حرف"));
function setMode(m){mode=m;$("msgTab").classList.toggle("active",m==="message");$("urlTab").classList.toggle("active",m==="url");$("fieldLabel").textContent=m==="message"?(english?"Paste message text":"الصق نص الرسالة"):(english?"Enter link as text":"أدخل الرابط كنص");$("content").placeholder=m==="message"?(english?"Example: Your account will be suspended...":"مثال: سيتم إيقاف حسابك خلال 10 دقائق..."):(english?"https://example.com":"https://example.com");$("output").classList.add("hidden")}
$("msgTab").onclick=()=>setMode("message");$("urlTab").onclick=()=>setMode("url");
$("sample").onclick=()=>{$("content").value=examples[mode];$("content").dispatchEvent(new Event("input"))};
$("reset").onclick=()=>{$("content").value="";$("content").dispatchEvent(new Event("input"));$("output").classList.add("hidden")};
function msgFlags(t){let rules=[
[/رمز\s*(التحقق|الدخول)|otp|one.time.password/i,"تطلب الرسالة رمز تحقق أو رمز دخول."],
[/كلمة المرور|password|بيانات الدخول/i,"تطلب الرسالة كلمة المرور أو بيانات الدخول."],
[/عاجل|فوراً|فورا|خلال\s*\d+|آخر فرصة|نهائي/i,"تستخدم لغة استعجال أو ضغط زمني."],
[/إيقاف حساب|ايقاف حساب|تجميد الحساب|إغلاق الحساب/i,"تلوّح بإيقاف الحساب أو إغلاقه."],
[/تحويل مبلغ|حوّل|حول مبلغ|رسوم استلام|بيانات البطاقة/i,"تطلب تحويلاً مالياً أو بيانات مالية."],
[/جائزة|ربحت|فزت|هدية مجانية/i,"تستخدم وعداً بجائزة أو هدية."],
[/اضغط هنا|انقر هنا|click here|https?:\/\//i,"تتضمن طلب الضغط على رابط أو رابطاً مباشراً."]];
return rules.filter(r=>r[0].test(t)).map(r=>r[1])}
function urlFlags(raw){let f=[];try{let u=new URL(raw.trim());if(u.protocol!=="https:")f.push("الرابط لا يستخدم HTTPS.");if(u.username||u.password)f.push("الرابط يتضمن بيانات دخول مضمنة بشكل غير معتاد.");if(u.hostname.startsWith("xn--")||u.hostname.includes(".xn--"))f.push("اسم النطاق يستخدم ترميزاً يستحق التحقق.");if(u.hostname.split(".").length>=5)f.push("اسم النطاق طويل أو متعدد الأجزاء.");if(/login|verify|secure|update|bank|gift|prize|claim/i.test(u.hostname+u.pathname))f.push("تظهر كلمات مرتبطة بتسجيل الدخول أو التحقق؛ ليست دليلاً وحدها على الاحتيال.");if(!f.length)f.push("لم ترصد القواعد البسيطة مؤشرات واضحة.");return f}catch(e){return ["صيغة الرابط غير مكتملة أو غير صحيحة؛ تعذّر تحليلها."]}}
function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(findings){let n=findings.length, cls=n>=3?"high":n>=1?"med":"low", label=n>=3?"مؤشرات متعددة":n>=1?"يحتاج إلى تحقق":"مؤشرات قليلة";let advice=n?"لا تضغط على الرابط ولا تشارك كلمة المرور أو رمز التحقق. تحقق عبر التطبيق أو الرقم الرسمي للجهة.":"عدم ظهور مؤشرات لا يعني أن المحتوى آمن. تحقق من المرسل عبر قناة رسمية مستقلة."; $("output").innerHTML=`<div class="outhead"><h3>نتيجة الفحص</h3><span class="badge ${cls}">${label}</span></div><p>المؤشرات المرصودة:</p><ul>${findings.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><div class="advice"><b>الإجراء المقترح:</b> ${advice}</div>`;$("output").classList.remove("hidden")}
$("analyze").onclick=()=>{let v=$("content").value.trim();if(!v){alert("أدخل نصاً أو رابطاً أولاً.");return}let f=mode==="message"?msgFlags(v):urlFlags(v);if(!f.length)f=["لم ترصد القواعد الحالية كلمات أو أنماطاً شائعة مرتبطة بالاحتيال."];render(f)};
$("langBtn").onclick=()=>{english=!english;document.body.classList.toggle("en",english);document.documentElement.lang=english?"en":"ar";document.documentElement.dir=english?"ltr":"rtl";$("langBtn").textContent=english?"عربي":"EN";$("scanTitle").textContent=english?"Check a message or link":"افحص رسالة أو رابطاً";$("fieldLabel").textContent=mode==="message"?(english?"Paste message text":"الصق نص الرسالة"):(english?"Enter link as text":"أدخل الرابط كنص");$("hint").textContent=english?"Do not enter passwords, OTPs or bank details.":"لا تضف كلمات مرور أو رموز تحقق أو بيانات بنكية.";};
